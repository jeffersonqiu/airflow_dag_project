.. _aiohttp-misc:

Miscellaneous
=============

Helpful pages.

.. toctree::
   :name: misc

   essays
   glossary

.. toctree::
   :titlesonly:

   changes

Indices and tables
------------------

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
